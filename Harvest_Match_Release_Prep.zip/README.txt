Harvest Match Android release preparation, Version 9.
Contains browser game, web app manifest, icons and offline service worker.
This is NOT an Android App Bundle (.aab). A trusted Android build environment, signing key, testing and Play Console submission are still required.
Host these files on HTTPS to test installable PWA/offline behavior. Local file opening does not activate the service worker.
Music requires a user tap to start. Optional rewarded ads are NOT integrated.
